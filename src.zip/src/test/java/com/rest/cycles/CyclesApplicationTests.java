package com.rest.cycles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CyclesApplicationTests {

	@Test
	void contextLoads() {
	}

}
