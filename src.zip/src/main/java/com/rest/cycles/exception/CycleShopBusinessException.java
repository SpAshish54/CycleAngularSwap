package com.rest.cycles.exception;

public class CycleShopBusinessException extends RuntimeException{
    public CycleShopBusinessException(String message) {
        super(message);
    }
}