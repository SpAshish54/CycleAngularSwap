package com.rest.cycles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyclesApplication {
	public static void main(String[] args) {
		SpringApplication.run(CyclesApplication.class, args);
	}

}
