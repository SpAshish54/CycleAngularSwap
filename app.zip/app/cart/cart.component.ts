import { Component } from '@angular/core';
import { Cycle } from '../cycle';
import { CycleService } from '../cycle.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

cycles : Cycle[] = [];

  constructor(private cycleService: CycleService) {}

  ngOnInit() : void {
    this.cycleService.getCartCycles().subscribe(res => this.cycles = res);
    console.log(this.cycles);
  }

}
