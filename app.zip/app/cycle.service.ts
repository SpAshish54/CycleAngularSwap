import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Brand } from './brand';
import { Observable, of } from 'rxjs';
import { Cycle } from './cycle';

@Injectable({
  providedIn: 'root'
})
export class CycleService {

  constructor(private _http:HttpClient) {}

  getAllBrand() : Observable<Brand[]> {
    return this._http.get<Brand[]>("http://localhost:8080/api/brand/list");
    
  }

  addNewBrand(name: string, qty: number) : Observable<Brand[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.post<Brand[]>("http://localhost:8080/api/brand/add", {name: name, qty: qty},
    {headers: headers});
  }

  restockCycle(id : number, count : number) : Observable<Brand[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.post<Brand[]>(`http://localhost:8080/api/brand/restock/${id}`, {qty : count}, 
    {headers:headers});
  }

  borrowBrandCycle(id : number, count: number) : Observable<Brand[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.post<Brand[]>(`http://localhost:8080/api/brand/borrow/${id}`, {qty : count}, {
      headers:headers
    });
  }

  countAllAvailableCycleByBrandId(id : number) : Observable<number> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.get<number>(`http://localhost:8080/api/cycle/countAvailableByBrand/${id}`,{headers: headers});
  }

  getAllBorrowedCycle() : Observable<Cycle[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.get<Cycle[]>("http://localhost:8080/api/cycle/borrowedList", {headers : headers});
  }

  getAllAvailableCycle() : Observable<Cycle[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer' + localStorage.getItem('token')
    });
    return this._http.get<Cycle[]>("http://localhost:8080/api/cycle/availableList", {headers : headers});
  }

  returnCycle(id : number) : Observable<Cycle[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this._http.post<Cycle[]>(`http://localhost:8080/api/cycle/return/${id}`, null, {headers: headers});
  }

  borrowCycle(id : number) : Observable<Cycle[]> {
    // const headers = new HttpHeaders({
    //   'Authorization': 'Bearer ' + localStorage.getItem('token')
    // });
    return this._http.post<Cycle[]>(`http://localhost:8080/api/cycle/borrow/${id}`, null);
  }

  addBrandToCart(id : number, count: number) : Observable<Brand[]>
  {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    console.log(id);
    return this._http.post<Brand[]>(`http://localhost:8080/api/brand/cart/${id}`, null, {
      headers:headers
    });
  }

  getCartCycles(): Observable<Cycle[]>{
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    console.log("entered getCartCycles()");
    return this._http.get<Cycle[]>("http://localhost:8080/api/cycle/CartList", {headers : headers});
  }  
}
