import { Brand } from "./brand";

export interface Cycle {
    id : number,
    brand : Brand,
    isAvailable : boolean
}